//from lab guide

const express = require('express')
const app = express()
const urlprefix = '/api'

const mongoose = require('mongoose');
const Post = require('./models/posts');
const fs = require('fs');
const posts = require('./models/posts');

// read the SSL CA certificate
const cert = fs.readFileSync('keys/cert.pem');
const  key = fs.readFileSync('keys/key.pem');

// setting up the options for the MongoDB connection
const options = {
    server: { sslCA: cert }
};

//connction string
const connectionstring = 'mongodb+srv://ST10083780:Admin123@cluster0.cis7glw.mongodb.net/'

//routes
const postRoutes = require("./routes/posts");
const userRoutes = require("./routes/user");

// connect to the database
mongoose.connect(connectionstring).then(() => {
    console.log("Connected to MongoDB")
   }).catch(() => {
    console.log("Could not connect to MongoDB")
   },options);

app.use(express.json());

// setting up CORS headers
app.use((reg,res,next) => 
{
   res.setHeader('Access-Control-Allow-Origin', '*');
    res.setHeader('Access-Control-Allow-Headers', 'Origin, X-Requested-With, Content-Type, Accept Authorization');
    res.setHeader('Access-Control-Allow-Methods', '*');
    next();
    
});

app.use(urlprefix + '/posts', postRoutes);
app.use(urlprefix + '/user', userRoutes);



module.exports = app;
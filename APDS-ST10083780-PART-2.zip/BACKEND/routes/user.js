const express = require('express');
const router = express.Router();
const User = require('../models/user');
const bcrypt = require('bcrypt');
const jwt = require('jsonwebtoken');

// POST route for user registration
router.post('/register', (req, res) => {
    bcrypt.hash(req.body.password, 10)
    .then((hash) => {
        const user = new User(
            { username: req.body.username, 
              password: hash 
            }
        )
        // save user to the database
        user.save().then((result) => {
            res.status(201).json({
                message: 'User created successfully',
                user: user
            });
        })
        .catch((err) => {
            res.sendStatus(500).json(
                {
                    message: 'Could not create user',
                    error: err
                }
             );
         });
    }); 
})

// POST route for user login
router.post('/login', async (req, res) => {
    const user_fetch = await User.findOne({ username: req.body.username })

    // check if user exists in the database
    if(user_fetch){
        const result = await bcrypt.compare(req.body.password, user_fetch.password);
    
        // check if password matches
        if(result){
            const token = jwt.sign(
                { username: user_fetch.username, userid: user_fetch.id},
            "secret_key_hahahaha",
            { expiresIn: '1h' }
        );

         res.status(200).json({
                message: 'User logged in successfully',
                username: user_fetch.username,
                token: token
        });
        // return the token
    } else {
        return res.status(401).json(
            { message: "Invalid username or password"
        });
    }
    }
});

// exports the router
    module.exports = router;

// import libraries
const express = require('express');
const router = express.Router();
const Post = require('../models/posts');
const checkAuth = require('../check-auth');

// GET route for posts
router.get('', (req, res) => {
    Post.find().then((posts) => {
        res.json(
            {
                message: 'Posts fetched successfully',
                posts: posts
            }
        )
    })
});

// POST routes for posts
router.post('', (req, res) => {
    const post = new Post(
        {
            id: req.body.id,
            caption: req.body.caption,
            departments: req.body.departments,
            priority: req.body.priority
        }
    )
// save a new post to database
    post.save().then(() => {
        res.status(201).json({
            message: 'Post created successfully',
            post:post
        })
    })
});

// DELETE route for posts, use ID of post to delete
router.delete('/:id', (req, res) => {
    Post.deleteOne({_id: req.params.id})
    .then((result) => {
        res.status(200).json({
            message: 'Post deleted successfully',
        })
    })
})

module.exports = router;
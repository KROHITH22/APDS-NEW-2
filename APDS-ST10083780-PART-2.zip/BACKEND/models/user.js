// import mongoose to interact with mongodb
const mongoose = require('mongoose');

// schema for user in mongodb
const userSchema = mongoose.Schema(
    {
        username: { type: String, required: true },
        password: { type: String, required: true }
    }
)

// export user model on the schema
module.exports = mongoose.model('User', userSchema);
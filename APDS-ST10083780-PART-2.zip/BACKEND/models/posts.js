// import mongoose to interact with mongodb
const mongoose = require('mongoose');

// schema for post in mongodb
const postSchema = mongoose.Schema(
    {
        id: { type: String, required: true },
        caption: { type: String, required: true },
        departments: { type: String, required: true },
        priority: { type: String, required: true }
    }
)

// export post model on the schema
module.exports = mongoose.model('Post', postSchema);